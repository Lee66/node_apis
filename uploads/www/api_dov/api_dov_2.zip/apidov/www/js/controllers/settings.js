angular.module('controllers')
.controller('SettingsCtrl',function($scope,$r, $q,$rs){
// productslist
  var load=function() {
       var product_list ={};
        $rs("products", product_list ).then(function(data){
          $scope.products=data.docs;
          $scope.$broadcast('scroll.refreshComplete');
          console.log(data);
          }, function(err){
          console.log(err);
        });
  };
  $scope.$on('$ionicView.enter', function() {
             console.log("$ionicView.enter");
        load();
  });
})
;