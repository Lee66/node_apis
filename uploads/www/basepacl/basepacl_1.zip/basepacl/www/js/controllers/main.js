angular.module('controllers', [])
.controller('AppCtrl', function($rootScope,$scope, $ionicModal, $timeout, validation, toaster, $state ,$rs, $cache , $ionicHistory,$ionicLoading) {
  $scope.form={};
  var load=function() {
       var product_list ={};
        $rs("products", product_list ).then(function(data){
          $scope.products=data.docs;
          $scope.$broadcast('scroll.refreshComplete');
          console.log(data);
          }, function(err){
          console.log(err);
        });
  };
  $scope.$on('$ionicView.enter', function() {
             console.log("$ionicView.enter");
        load();
  });
  $scope.doRefresh=function(){
       load();
  };
})
;
