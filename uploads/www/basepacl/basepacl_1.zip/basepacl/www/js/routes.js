angular.module('starter')
.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
  .state('app', {
    url: "/home",
    templateUrl: "templates/home.html",
    controller: 'AppCtrl'
  })
 .state('settings', {
    url: "/settings",
    templateUrl: "templates/settings.html",
    controller: 'SettingsCtrl'
  })
  ;
   $urlRouterProvider.otherwise('/home');
});
