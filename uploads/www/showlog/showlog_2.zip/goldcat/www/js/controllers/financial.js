angular.module('controllers')
.controller('rechargeCtrl', function($scope, $location,$ionicModal,toaster, $state, $ionicHistory, validation,$stateParams,$r,$cache,$sce,$ionicActionSheet,$jf,$h,$timeout) {
	$scope.form={};
	$scope.form.submits=false;
	$scope.form.checkmsg=false;
	$scope.form.input_money;
    $scope.form.payway={ text: '账户支付',payType:'02'};
    $scope.form.paytypes=[{ text: '账户支付',payType:'02'}];			
	$scope.chosepayway = function(val) {
						    console.log(val);
						    if (val != '08') {
						      var hideSheet = $ionicActionSheet.show({
						            titleText: '选择支付方式',
						            buttons: $scope.form.paytypes,
						            cancelText: '取消',
						            buttonClicked:function(index){
						                    console.log($scope.form.paytypes[index]);                  
						                    $scope.form.payway=$scope.form.paytypes[index];
						                    hideSheet();
						            }
						        });
						     };}; 
     //页面跳转							 
 	$ionicModal.fromTemplateUrl('templates/rechange_confirm.html', {
		     scope: $scope
		   }).then(function(modal) {
		     $scope.showcontent = modal;
		   });
	$scope.showConfirm=function(){
		   $scope.showcontent.show();
	};
	$scope.closeConfirm = function() {
	      $scope.showcontent.hide();
	};
	var load=function(){
         //获取即付宝账户信息
			    var JfpalAccount=[{}];
			    $r("queryJfpalAccount", JfpalAccount).then(function(data){
			    console.log(data);
			    if(data.respHead.code=="0000"){
					   $scope.form.submits=true;  
		               $scope.form.balance= data.respBean.data[0].balance  ;		         
			    }else{
			            var msg=data.respHead.message;   
			            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 			      
			       }},function(err){
			          console.log(err);
			      });
	 };	  	
	$scope.$on('$ionicView.enter', function() {
	      load(); 
		  $scope.form.paytypes[{
			  'text':"账户支付",
			  'payType':'02',
			  }];
	  });	
	  
	//限定输入金额格式
	$scope.checkNum=function(num){
		if(isNaN(num.value)){
			num.value='';
		}
		if(num!=null){
			if(num.value.toString().split('.')>1 && num.value.toString().split('.')[1].length>2){
				num.value='';
			}
		}
	};
	$scope.change=function () {
		var date=((parseFloat($scope.form.input_money)*100).toFixed(2)).split(".");
		console.log(date);
		if(date[1]>0){
            $scope.form.input_money=parseFloat(date[0])/100;    
        };
	}; 			  	  
	 //判断充值金额,创建充值订单		  		
    $scope.creat_order=function(){
		 var msg;			
		 console.log($scope.form);
		 $scope.form.input_money=parseFloat($scope.form.input_money);
		if(validation.isnull($scope.form.input_money)){
			if(validation.money($scope.form.input_money)){
				  if(validation.isnull($scope.form.balance)){
					   if(validation.money($scope.form.balance)){
						     if(($scope.form.input_money)*100>=1){
                                 if(($scope.form.input_money)*100<=parseFloat($scope.form.balance))
								 {
								  	$scope.form.submits=false;									 						        																										
                                    var creatOrder=[{					       
										"productCode":$stateParams.productCode,
										"amountProduct":parseFloat((($scope.form.input_money)*100).toFixed(2)),
										'payType':"02",
										'bizType':'CZ'																									
									}];
									$r('createOrder',creatOrder).then(function(data){							
									  console.log(data);																																													  
										  if(data.respHead.code=="0000"){
											  	  $scope.form.amountTotal= data.respBean.data[0].amountTotal;
										          $scope.form.orderId= data.respBean.data[0].orderId;		
												  $timeout(function(){
													  $scope.form.submits=true;
													},2000);	
											  	  $scope.showcontent.show();														
												  selectLoad();	 									 
										  }else{
											var msg=data.respHead.message;
											$timeout(function(){
													  $scope.form.submits=true;
													},2000);   
	                            			return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
										  }
									  },function(err){
										  console.log(err);
									  });												
								}else{
									msg='账户余额不足,请充值 !';
									
							 }}else{
								 msg="充值金额需大于1分 !";							
					  }}else{
							msg="账户余额不足,请充值 !";
							return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
				}}else{
						msg="无账户余额 !";					
		  }}else{												
				msg="请输入正确的充值金额 !";			
	  }}else{
			msg="请输入充值金额 !";
		};
		if(msg){
			   return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
		}; 																		
	 };		
	 //	 查询充值订单	
 var  selectLoad=function(){ 
      var jf_orderDetail=[{
      'orderId': $scope.form.orderId
    }];
    $r("jf_orderDetail", jf_orderDetail ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){         
            $scope.form.jf_orderDetail=data.respBean.data[0];
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });	
	 };		 
	 		 	  
		//确认订单					
		$scope.checksubmit=function(obj){
			console.log(obj);
			var msg;
			if(validation.isnull(obj.password)){
				$scope.form.submits=false;
					$scope.form.subtext="处理中...";				
				$jf.getTokenData().then(function(tokenData){
					$jf.encodeWithRSA(tokenData.phone,obj.password).then(function(encodePassword){
						  var payMoney=[{
							'orderId':obj.orderId,
							'password':encodePassword,
							'payType':'02',
							'bizType':'CZ',
							'amountTotal':obj.amountTotal,
							'productCode':obj.prodcutCode,														
							}];
							$scope.form.paytypes.push('payMoney');
			              $r("payMoney",payMoney).then(function(data){
							console.log(data);
							var msg;
							msg=data.respHead.message;					
							if(data.respHead.code=="0000"){
								$timeout(function(){
									$scope.form.submits=true;
									$scope.form.subtext='确定';
								},1000);							
								msg="恭喜您,充值成功 !";								
								$scope.closeConfirm();
								$scope.form.input_money='';
								$scope.form.password='';
								$state.go('app');
								return toaster.pop('warning',null,'<ul><li>'+msg+'</li></ul>',null,'trustedHtml');
							}else{
								$timeout(function(){
								  $scope.form.submits=true;
								  $scope.form.subtext='确定';
								},1000);
								return toaster.pop('warning',null,'<ul><li>'+msg+'</li></ul>',null,'trustedHtml');
							}
						},function(err){
							console.log(err);
							$timeout(function(){
								  $scope.form.submits=true;
								  $scope.form.subtext='确定';
								},1000);
								var msg;
								 msg=err.respHead.message;
								return toaster.pop('warning',null,'<ul><li>'+msg+'</li></ul>',null,'trustedHtml');
						 });														
					 });
			    });
			}else{
				msg="登录密码不能为空 !";
			    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
			}
		};							 
  
})



//提款
.controller('drawingCtrl', function($scope, $ionicModal,toaster,$location,$ionicPopup, $state, $ionicHistory, $jf,validation,$stateParams,$r,$cache,$sce,$ionicActionSheet, $h,$timeout) {	
	$scope.form={};
	$scope.form.submits=false;
	$scope.form.out_money;	
    $scope.form.payway={ text: '账户支付',payType:'02'};
    $scope.form.paytypes=[{ text: '账户支付',payType:'02'}];
	var load=function(){
		   //钱包余额
		var myAccount=[{}];
	    $r("myAccount", myAccount ).then(function(data){
	       console.log(data);
	        if(data.respHead.code=="0000"){
				 $scope.form.submits=true;  
	            $scope.form.myaccount=data.respBean.data[0];
	          }else{
	            var msg=data.respHead.message;   
	            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
	          }
	      },function(err){
	          console.log(err);
	      });
	 };
//	页面跳转 
	$ionicModal.fromTemplateUrl('templates/drawing_confrim.html', {
	     scope: $scope
	   }).then(function(modal) {
	     $scope.showcontent = modal;
	   });
	   $scope.showConfirm=function(){
		   $scope.showcontent.show();
		 };
		 $scope.closeConfirm = function() {
	      $scope.showcontent.hide();
		 };
 
//   感叹号提示
    $scope.tk_pop=function(){
		    $ionicPopup.alert({
            title:"",
            template:"当日充值金额，可在下一个工作日提取！",
            buttons:[{
              text:"确定",
              onTap:function(){
                console.log('done');
              }			
            }],
			cssClass:"alertpopup"
          });
	};
	$scope.change=function () {
        console.log((parseFloat($scope.form.out_money)*100));
		var date=((parseFloat($scope.form.out_money)*100).toFixed(2)).split(".");
		console.log(date);
        if(date[1]>0){
            $scope.form.out_money=parseFloat(date[0])/100;    
        };
	}; 	
//		 创建提款订单	
		$scope.createTK=function(obj){			
			var msg;				
			$scope.form.out_money=parseFloat($scope.form.out_money);
			if(validation.isnull($scope.form.out_money)){
				if(validation.money($scope.form.out_money)){
					  if(validation.isnull($scope.form.myaccount.balanceLow)){
						   if(validation.money($scope.form.myaccount.balanceLow)){
							     if(($scope.form.out_money)*100>=1){
	                                 if(($scope.form.out_money)*100<=parseFloat($scope.form.myaccount.balanceLow))
									 {	
									  $scope.form.submits=false;	 								 						        																										
	                                   var creatOrder=[{					       
										"productCode":$stateParams.productCode,
										"amountProduct":parseFloat((($scope.form.out_money)*100).toFixed(2)),
										'payType':"02",
									    'bizType':'TK'																
										}];
										$r('createOrder',creatOrder).then(function(data){									   
										  console.log(data);				  
										  if(data.respHead.code=="0000"){
											   $scope.form.amountTotal= data.respBean.data[0].amountTotal;
									           $scope.form.orderId= data.respBean.data[0].orderId;	
											   $timeout(function(){
													  $scope.form.submits=true;
													},2000);
											   $scope.showcontent.show();			 
											}else{
												$timeout(function(){
													  $scope.form.submits=true;
													},2000);
												var msg=data.respHead.message;   
	                            				return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
										  	}
								      },function(err){
									  console.log(err);
								    });														
								}else{
									msg='当前可提余额不足!';								
								} }else{
									 msg="提款金额需大于1分 !";																
								 }}else{
									$scope.form.submits=false;
									msg="账户余额不足 !";
									return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 																											
						}}else{
							msg="当前可提余额不足 !";						
						}}else{				
					msg="请输入正确的提款金额 !";				
				}}else{
				msg="请输入提款金额 !";
			};
			if(msg){
				   return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
			}; 		
		};		
	 $scope.$on('$ionicView.enter', function() {
      load();
  });
		//确认提款订单						
	  $scope.checkTK=function(obj){
			console.log(obj);
			var msg;
			if(validation.isnull(obj.password)){
				$scope.form.submits=false;
				$scope.form.subtext="处理中...";
				$jf.getTokenData().then(function(tokenData){
					$jf.encodeWithRSA(tokenData.phone,obj.password).then(function(encodePassword){
					  var withdrawalsMoney=[{
						'orderId':obj.orderId,
						'password':encodePassword,
						'payType':'02',
						'bizType':'TK',
						'amountTotal':obj.amountTotal,
						'productCode':obj.myaccount.prodcutCode														
						}];
						$scope.form.paytypes.push('withdrawalsMoney');
		              $r("withdrawalsMoney",withdrawalsMoney).then(function(data){
						console.log(data);
						var msg;
						msg=data.respHead.message;
						if(data.respHead.code=="0000"){
							$timeout(function(){
								$scope.form.submits=true;
								$scope.form.subtext='确定';
							},1000);
							$scope.closeConfirm();
							msg="恭喜您,提款成功 !";
							$scope.form.out_money='';
							$scope.form.password='';
							$state.go('app');
							return toaster.pop('warning',null,'<ul><li>'+msg+'</li></ul>',null,'trustedHtml');
						}else{
							$timeout(function(){
							  $scope.form.submits=true;
							  $scope.form.subtext='确定';
							},1000);
							return toaster.pop('warning',null,'<ul><li>'+msg+'</li></ul>',null,'trustedHtml');
						}
					},function(err){
						console.log(err);
						$timeout(function(){
							  $scope.form.submits=true;
							  $scope.form.subtext='确定';
							},2000);
							var msg;
							msg=err.respHead.message;
							return toaster.pop('warning',null,'<ul><li>'+msg+'</li></ul>',null,'trustedHtml');
					});														
					});
			    });
			}else{
				msg="登录密码不能为空 !";
			    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
			}
		};
	
});