angular.module('services', ['ionic'])
.factory('$r', function($http, $interface, $rootScope, _, $cache, $jf, $q) {
  return function(api, reqbody){
    // merge with cordova application
    // secure msg
    //  'reqContent={"reqHead":{"transDate":"20150101","transTime":"120000","application":"login","serialID":"222222","osType":"andriod2.4","version":"1.0","phone":"18988888888"},"reqBean":{"detail":[{"userName":"admin","password":"DFAF016D15CB38C487B5DB9E0ADA1FCC8A8959E0"}]}}&sign=E9CB490CAF0FCB2E2682409B483EC71A'
    // msg = {
    //   reqContent: '{"reqHead":{"transDate":"20150101","transTime":"120000","application":"login","serialID":"222222","osType":"andriod2.4","version":"1.0","phone":"18988888888"},"reqBean":{"detail":[{"userName":"admin","password":"DFAF016D15CB38C487B5DB9E0ADA1FCC8A8959E0"}]}}',
    //   sign: 'E9CB490CAF0FCB2E2682409B483EC71A'
    // };
    
    var q = $q.defer(); 
    $jf.getTokenData().then(function(tokenData){
        console.log(tokenData);
        var reqhead = {
            "reqHead": {
                "version": "1.0.0",
                "application": api,
                "sysSource": "jfpal",
                "token": tokenData.token,
                "phone": tokenData.phone
            }
        };
        var reqbean = {
            "reqBean": {
                "detail":  reqbody,
                "cat": _.omit(tokenData, 'token')
            }
        };
        var msg = _.merge(reqhead, reqbean);
        console.log(msg);
        $jf.getEnv().then(function(data){
        // q.resolve(data);
        // q.resolve(_.merge(data, reqhead.reqHead));
            msg.reqHead = _.merge(data, reqhead.reqHead);
            console.log(msg);
            var reqContent = JSON.stringify(msg);
            $jf.digestWithMD5(reqContent).then(function(sign){
                var reqData = 'reqContent='+ encodeURI(JSON.stringify(msg)) + "&sign=" + sign;
                var req = {
                    method: 'POST',
                    url: $interface.getUrl(api),
                    headers: {
                        'Content-Type': "application/x-www-form-urlencoded",
                },
                data: reqData
                };
                $http(req).error(function(err){
                    console.log(err);
                    $rootScope.$broadcast("network:error", err);
                    q.reject(err);
                }).success(function(data){
                    // q.resolve(data);
                    // console.log(JSON.stringify(data));
                    // token invalidation
                    if(data.respHead.code === 'FP02'||data.respHead.code === 'FP91'){
                        $rootScope.$broadcast("token:invalidation", data);
                        $jf.OpenSignPanelWhenSessionExpired();
                        q.reject(data);
                    }else {
                        q.resolve(data);
                    }
                    // if(data.respHead.code === 'FP99'){
                    //   $rootScope.$broadcast("token:invalidation", data);
                    // }
                    // if data.respHead.code === 'FP02'
                    // $rootScope.$broadcast("token:invalidation", data);
                    // sign error
                    // $rootScope.$broadcast("sign:error", data);
                });
            });
        } ,function(err){
            q.reject(err); 
        });
    });
    return q.promise;
  };
})
.factory('$interface', function(API_URL){
  return {
    getUrl: function(api){
      return API_URL + api;
    }
  };
})
.service("validation", function(){
    this.isnull=function(text){
      if(text == undefined || text == null || text == "")
      {
        return false;
      }else{
        return true;
      }
      // return (text === undefined || text == null || text === "");
    };
    this.money=function(money){
      return  (/^\d+(\.\d+)?$/.test(money));
    };
    this.isNumber100Times = function(money){
        return (/^[0-9]*[0-9]$/i.test(money) && (money % 10000===0));
    };
    this.phone =function(mobile){
        return (/^1[3|4|5|7|8][0-9]\d{8}$/.test(mobile));
    };
    this.number = function(number){
        return(/^[1-9]+\d*$/.test(number));
    };
    this.cardid = function(cardid){
      return(/^(\d{16}|\d{19})$/.test(cardid));
    };
})

.service('$h', function($state, $ionicHistory) {

  this.getHistory = function(){
    return $ionicHistory.viewHistory();
  };

  this.setBackToState = function(state){
    var histack = $ionicHistory.viewHistory().histories[name? name: "root"].stack,
        views = $ionicHistory.viewHistory().views,
        viewId,
        the_idx;

    histack.forEach(function(view, idx) {
      if(view.stateName == state) {
        viewId = view.viewId
        the_idx  = idx;
        return;
      }
    });
    if(viewId){
      $ionicHistory.viewHistory().backView = views[viewId]
      for(var i = histack.length; i > the_idx ; i--){
        delete histack[i];
      }
    }
    return viewId;
  }

  this.popToState = function(state){
    
    this.setBackToState(state);
    $ionicHistory.goBack();
  }
  
  this.gotoapp=function(){
      $state.go("app");
      $ionicHistory.nextViewOptions({
         disableAnimate: true,
         //disableBack: true
         historyRoot: true,
         expire: 100
      });
  };
})

.factory("$cache", function(){
  var user = {
      token: "0000",
      username:"",
      phone: "15121074003",
      idcard: ""
  },
  withdraw_bank= {};
  return {
    resetToken: function(){
      user.token = "0000"; 
    },
    setUser:function(user_o){
      user=user_o;
    },
    getPhone: function(){
     return user.phone; 
    },
    getToken: function(){
      return user.token;
    },
    setToken: function(value){
      user.token = value;
      // todo store token to app
    },
    setPhone: function(phone){
      user.phone = phone;
    },
    getBank: function(key){
        return withdraw_bank[key];
    },
    setBank: function(key,bank){
        withdraw_bank[key] = bank;
    },
    getIdCard: function(){
      return user.idcard;
    },
    getUserName:function(){
        return user.username;
    }
  };
})
.filter('bank_url', function() {
  return function(url) {
    return "./img/bank_icons/bank_" + url+"@2x.png";
  };
})
.filter('img_url', function() {
  return function(url) {
    return "./img/public/" + url+".png";
  };
})
.filter('tomoney', function() {
    return function(s, n) { 
          n = n > 0 && n <= 20 ? n : 2;
          var money = parseFloat(s);
          if(money){
            s = ( money / 100 ).toFixed(n) + "";
            var l = s.split(".")[0].split("").reverse(), r = s.split(".")[1];
            t = "";
            for (i = 0; i < l.length; i++) {
              t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
            }
            return t.split("").reverse().join("") + "." + r;
          }else if (s == 0 ){
            return "0.00"
          } else {
            return '---';

          }
    };
})
.filter('todate', function() {
    return function(thisdate) { 
      if (thisdate) {
        var y=thisdate.substr(0,4);
        var m=thisdate.substr(4,2);
        var d=thisdate.substr(6,2);
        return y+'-'+m+'-'+d;
      }else{
        return  '---';
      };
    };
})
.filter('totime',function(){
  return function(thistime){
    if (thistime) {
      var h=thistime.substr(0,2);
      var m=thistime.substr(2,2);
      return h+':'+m;
    }else{
      return '---';
    };
  };
})
.filter('hidephone', function() {
    return function(thisphone) {
      if (thisphone) {
        return thisphone.substr(0,4)+'****'+thisphone.substr(7,4)
      }else{
        return  '---';
      };
    };
})
.filter('tofloat', function() {
    return function(tofloat) { 
      if (tofloat||tofloat==0) {
        var result=parseFloat(tofloat*100).toFixed(2);
        return result;
      }else{
        return  '---';
      };
    };
})
;
