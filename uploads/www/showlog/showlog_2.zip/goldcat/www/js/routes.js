angular.module('cat')
.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
  .state('app', {
    url: "/mainlist",
    templateUrl: "templates/mainlist.html",
    controller: 'MainListCtrl'
  })
  .state('main', {
    url: "/main",
    templateUrl: "templates/main.html",
    controller: 'MainCtrl'
  })
  //jym
  .state('productdetail', {
    url: "/productdetail/:productCode/:action",
    templateUrl: "templates/productdetail.html",
    controller: 'productdetailCtrl'
  })
  //wangxin
  .state('productinfo', {
    url: "/productdetail/:productCode/:info",
    templateUrl: "templates/productinfo.html",
    controller: 'WXproductdetailCtrl'
  })
  //common
  .state('comproductinfo', {
    url: "/productdetail/:productCode/:info",
    templateUrl: "templates/comproductinfo.html",
    controller: 'comproductinfoCtrl'
  })
  //我的资产
  .state('account', {
    url: "/account",
    templateUrl: "templates/account.html",
    controller: 'AccountCtrl'
  })
  //收益详情
  .state('earndetail', {
    url: "/earndetail",
    templateUrl: "templates/earndetail.html",
    controller: 'EarndetailCtrl'
  })
  //收益明细
  .state('earnlist', {
    url: "/earnlist",
    templateUrl: "templates/earnlist.html",
    controller: 'EarnlistCtrl'
  })
  //交易明细
  .state('tradingrecord', {
    url: "/tradingrecord",
    templateUrl: "templates/tradingrecord.html",
    controller: 'TradingrecordCtrl'
  })
  .state('sendmsg', {
    url: "/sendmsg",
    templateUrl: "templates/sendmsg.html",
    controller: 'TradingrecordCtrl'
  })
  //取出
   .state('takeout', {
    url: "/takeout/:productCode",
    templateUrl: "templates/takeoutmoney.html",
    controller: 'TakeoutCtrl'
  })
  //购买
  .state('order', {
    url: "/order/:productCode/:productTypeId/:singleQuantityAmount",
    templateUrl: "templates/order.html",
    controller: 'OrderCtrl'
  })
  //购买网信
  .state('orderwx', {
    url: "/wxorder/:productCode/:productTypeId",
    templateUrl: "templates/orderwx.html",
    controller: 'OrderWXCtrl'
  })
  //公用创建订单
  .state('ordercom', {
    url: "/ordercom/:productCode/:productTypeId",
    templateUrl: "templates/ordercom.html",
    controller: 'OrderComCtrl'
  })
  //订单确认
  .state('orderdetail', {
    url: "/orderdetail/:orderId",
    templateUrl: "templates/orderdetail.html",
    controller: 'OrderDetailCtrl'
  })
  //网信订单确认
  .state('WXorderdetail', {
    url: "/wxorderdetail/:orderId",
    templateUrl: "templates/wxorderdetail.html",
    controller: 'WXOrderDetailCtrl'
  })
  //公用订单确认
  .state('orderComdetail', {
    url: "/orderComdetail/:orderId/:proaction",
    templateUrl: "templates/ordercomdetail.html",
    controller: 'OrderComDetailCtrl'
  })
  //活动详情
  .state('activity', {
    url: "/activity",
    templateUrl: "templates/activity.html",
    controller: 'activityCtrl'
  })
  //合同列表
  .state('rulelist', {
    url: "/rulelist",
    templateUrl: "templates/rulelist.html",
    controller: 'rulelistCtrl'
  })
  //理财账户充值
  .state('recharge', {
    url: "/recharge",
    templateUrl: "templates/recharge.html",
    controller: 'rechargeCtrl'
  })
  //理财账户提款
  .state('drawing', {
    url: "/drawing",
    templateUrl: "templates/drawing.html",
    controller: 'drawingCtrl'
  })
  ;
  $urlRouterProvider.otherwise('/mainlist');

});
