angular.module('controllers')
.controller('AccountCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r) {
	console.log('in main');
  $scope.form={};
	$scope.$on('$ionicView.enter', function() {
    var myAccount=[{}];
    $r("myAccount", myAccount ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            $scope.form.myaccount=data.respBean.data[0];
            $scope.form.accountnum=parseFloat($scope.form.myaccount.productBalance)+parseFloat($scope.form.myaccount.blockedBalance);
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
	var amountList=[{}];
    $r("amountList", amountList ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            $scope.form.myproduct=data.respBean.data;
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
    });
	$scope.gotostate=function(obg){
    console.log(obg);
      if(obg.productAscription=="JYM"){
        $state.go('productdetail',{productCode:obg.productCode,action:obg.productAscription});
      }else if(obg.productAscription=="WANGXIN"){
        $state.go('productinfo',{productCode:obg.productCode,info:obg.productAscription});  
      }else{
          $state.go('comproductinfo',{productCode:obg.productCode,info:obg.productAscription});  
      }
//    $state.go('WXorderdetail',{orderId:data.respBean.data[0].orderId}); 
  };
    
})
.controller('EarndetailCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory) {
	console.log('in main');
})
.controller('TradingrecordCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r) {
	    $scope.clickstatus='01';
      $scope.form={};
      $scope.form.borrowlist;
      $scope.form.borrower_mobile;
      var msg;
      var load = function() {
              var reqBody= [{
                'transType':$scope.clickstatus
              }];
              $r("transList", reqBody ).then(function(data){
                  console.log(data);
                   if(data.respHead.code=="0000"){
                        $scope.form.borrowlist=data.respBean.data;
                        console.log(data.respBean.data);
                    }else{
                        msg=data.respHead.message;   
                      return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                    }
                   
                },function(err){
                  console.log(err);
              });
          }
      $scope.$on('$ionicView.enter', function() {
             console.log("$ionicView.enter");
             load();
        });
      $scope.click=function(status){
	      if (status === '00'){
	        $scope.form.hrefstatus = "#/app/transdetail/";
	      }else{
	        $scope.form.hrefstatus = "";
	      }
	      $scope.clickstatus=status;
          $scope.form={};
         load();
      };
})
.controller('EarnlistCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r,_) {
	console.log('in main');
   $scope.form={};
   $scope.noMoreItemsAvailable = true;
   $scope.form.pageIndex=1;
   $scope.form.incomeList={},$scope.form.allincomeList=[];
   var msg;
   var load = function() {
             var myAccount=[{}];
              $r("myAccount", myAccount ).then(function(data){
               console.log(data);
                if(data.respHead.code=="0000"){
                    $scope.form.myaccount=data.respBean.data[0];
                  }else{
                    var msg=data.respHead.message;   
                    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  }
              },function(err){
                  console.log(err);
              });
              var incomeList= [{
                 "pageNum":10,
                 "pageIndex":1,
              }];
              $r("incomeList", incomeList ).then(function(data){
                  console.log(data);
                   if(data.respHead.code=="0000"){
//                        $scope.form.incomeList=data.respBean.data;
                        console.log(data.respBean.data);
//                        acomlist=[{id:'1',incomeDate: "20150815",incomeAmount:90},];
                        //console.log($scope.forloop(acomlist));
                        if(data.respBean.data.length>0){
                          $scope.form.incomeList=data.respBean.data;
                          $scope.doforloop();
                        }else{
                          $scope.form.incomeList={};
                        }
                        $scope.form.pageIndex=2;
                        $scope.noMoreItemsAvailable = false;
//                        $scope.form.incomeList=$scope.forloop(data.respBean.data);
                        console.log($scope.form.incomeList);

                    }else{
                        msg=data.respHead.message;   
                      return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                    }
                   
                },function(err){
                  console.log(err);
              });
      };
      $scope.$on('$ionicView.enter', function() {
             console.log("$ionicView.enter");
             load();
      });
      $scope.doforloop=function(){
       
        console.log($scope.form.incomeList);
        $scope.form.allincomeList=$scope.forloop($scope.form.incomeList);
         $scope.$broadcast('scroll.refreshComplete');
      };
      $scope.forloop=function(allincom){
        var time=allincom[0].incomeDate;
        var timearry=[],imcomelist=[];
        timearry.push(time);
        for(var i=0;i<allincom.length;i++){
          if(allincom[i].incomeDate!=time){
            if(!$scope.in_array(allincom[i].incomeDate,timearry)){
                timearry.push(allincom[i].incomeDate);
              }
          }
        }
        for(var j=0;j<timearry.length;j++){
          imcomelist[j]=$scope.getcom(allincom,timearry[j]);
        }
//        console.log(imcomelist);
          return imcomelist;
      };
      $scope.in_array=function(needle, haystack) {
      for(var i in haystack) {
       if(haystack[i] == needle) {
        return true;
       }
      }
      return false;
     };
      $scope.getcom=function(allincom,time){
        var arr={};
        var incomeAmount=[];
        var acount=0;
        for(var i=0;i<allincom.length;i++){
          if(time==allincom[i].incomeDate){
              incomeAmount.push(allincom[i]);
              acount+=allincom[i].incomeAmount;
          }
        }
        arr['account']=acount;
        arr['incomeAmount']=incomeAmount;
        arr['incomeDate']=time;
        return arr;
      };
       $scope.doRefresh=function(){
        load();
      };
      $scope.loadMoreData = function() {
             var reqBody= [{
                  "pageNum":10,
                  "pageIndex":$scope.form.pageIndex,
                }];
             $r("incomeList", reqBody).then(function(data){
                console.log(data);
                 if(data.respHead.code=="0000"){
                      if(($scope.form.incomeList && $scope.form.incomeList.length >= data.respBean.page.totalRecord)||data.respBean.page.totalRecord==0){
                          $scope.noMoreItemsAvailable = true;

                      }else{
                        _.each(data.respBean.data, function(item){
                        $scope.form.incomeList.push(item);
                        });
                        $scope.doforloop();

                        $scope.form.pageIndex=data.respBean.page.pageIndex+1;
                      }
                  }else{
                    $scope.noMoreItemsAvailable = true;
                    var msg=data.respHead.message;   
                    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  }
              },function(err){
                $scope.noMoreItemsAvailable = true;
                console.log(err);
            });
            $scope.$broadcast('scroll.infiniteScrollComplete');
            
          };
})
;