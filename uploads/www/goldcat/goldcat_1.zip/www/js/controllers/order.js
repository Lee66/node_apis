angular.module('controllers')
.controller('OrderCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, validation,$stateParams,$r,$cache,$sce,$ionicActionSheet, $h,$timeout,$ionicPopup) {
//  console.log($stateParams.productCode);
	$scope.form={};
  $scope.form.submits=false;
  $scope.form.agree=true;
  $scope.form.count=1;
  $scope.form.payway={};
  $scope.form.paytypes=[];
	//rules
 	$ionicModal.fromTemplateUrl('templates/showrules.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.showrules = modal;
  });
	//rules
	$scope.showrulesview=function(){
	  $scope.showrules.show();
	};
	$scope.closerules = function() {
      $scope.showrules.hide();
	};
   //chose payway
  //action sheet
  $scope.chosepayway = function(val) {
    console.log(val);
      var hideSheet = $ionicActionSheet.show({
            titleText: '选择支付方式',
            buttons: $scope.form.paytypes,
            cancelText: '取消',
            buttonClicked:function(index){
                    console.log($scope.form.paytypes[index]);
                    //合同详情
                    $scope.form.payway=$scope.form.paytypes[index];
                    hideSheet();
            }
      });
  };
  //product
  var load=function(){
      $scope.form.count=1;
      $scope.form.money=parseFloat($stateParams.singleQuantityAmount)*$scope.form.count;
      var financialBuy=[{
      'productCode':$stateParams.productCode
      }];
      $r("jym_financialBuy", financialBuy ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            //$scope.form.msg=data.respBean;
            $scope.form.product=data.respBean.data[0];
            $scope.tirtle="金银猫金包银投资协议";
            $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.yiledTakeOutRule);
//            $scope.form.money=parseFloat($stateParams.singleQuantityAmount)*$scope.form.count;
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
      
      var JfpalAccount=[{"productCode":$stateParams.productCode}];
      $r("productPayAble", JfpalAccount ).then(function(data){
       console.log(data);
       if(data.respHead.code=="0000"){
         $scope.form.submits=true;
         $scope.form.myaccount=data.respBean.data[0];
         if($scope.form.myaccount.balance==0){
           $scope.iopop();
         }
       }else{
          var msg=data.respHead.message;   
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
       }
      },function(err){
          console.log(err);
      });
      
      //获取支付方式
      var paymentMode=[{productTypeId:$stateParams.productTypeId}];
      $r("paymentMode", paymentMode ).then(function(data){
       console.log(data);
       if(data.respHead.code=="0000"){
         angular.forEach(data.respBean.data, function(element, idx) {
            var tmp = {
              text : element.typeName,
              payType :element.typeCode,
            };
            $scope.form.paytypes.push(tmp);
//            $scope.form.payway = tmp;
            console.log($scope.form.paytypes);
          });
          $scope.form.payway=$scope.form.paytypes[0];
       }else{
          var msg=data.respHead.message;   
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
       }
      },function(err){
          console.log(err);
      });

      
  };
  $scope.$on('$ionicView.enter', function() {
      $scope.form.payway={};
      $scope.form.paytypes=[];
      load();
  });
  //input actions
  $scope.putfocus=function(){
    console.log('in putfocus');
    var thecount=$scope.form.count;
    $scope.form.count='';
    $timeout(function(){
       $scope.form.count=thecount;
    } ,100); 
  };
  $scope.change=function(){
    if($scope.form.count&&$scope.form.count==0)
    {
      $timeout(function(){
       $scope.form.count=1;
      $scope.form.money=parseFloat($stateParams.singleQuantityAmount)*$scope.form.count;
      } ,200); 
    }else if($scope.form.count&&$scope.form.count<0){
      $scope.form.count=1;
      $scope.form.money=parseFloat($scope.form.product.singleQuantityAmount)*$scope.form.count;
    }else{
      $scope.form.money=parseFloat($stateParams.singleQuantityAmount)*$scope.form.count;
    }
    
  };
  $scope.addcount=function() {
    $scope.form.count=$scope.form.count+1;
    $scope.change();
  };
  $scope.delcount=function() {
    if($scope.form.count==1){
      $scope.form.count=1;
    }else{
      $scope.form.count=$scope.form.count-1;  
    }
    $scope.change();
  };
  $scope.buyall=function(){
   if($scope.form.myaccount){
      $scope.form.count=parseInt($scope.form.myaccount.balanceAble/$stateParams.singleQuantityAmount);
      console.log($scope.form.count);
      $scope.change();  
    }else{
      var msg='获取可用余额失败';   
      return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
    }
  };
  //no account money
  $scope.iopop=function(){
       $ionicPopup.show({
              template: '<div class="list_cell text_align_center">可用余额不足,请充值</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '充值',
                  type: 'button-positive',
                  onTap: function () {
                   $state.go('recharge');
                  }
                },],
              cssClass:"alertpopup"
       });
    };
  
  $scope.$watch("form.count", function(newV, oldV){
    console.log(newV, oldV);
    var status=(/^[0-9]+\d*$/.test(newV));
    console.log(status);
    if(status){
      $scope.form.count = newV;  
    }
  });
  //   感叹号提示
  $scope.tk_pop=function(){
		    $ionicPopup.alert({
            title:"",
            template:"当日充值金额只允许购买T+0的标,不可购买T+1的标",
            buttons:[{
              text:"确定",
              onTap:function(){
                console.log('done');
              }			
            }],
			cssClass:"alertpopup"
          });
	};
  //create order
  $scope.create_order=function(){
     var msg;
//     console.log($scope.form.money<=$scope.form.account.balance);
     console.log($scope.form);

  if(validation.isnull($scope.form.count)){
     if(validation.number($scope.form.count)){
       if(validation.isnull($scope.form.money)){
          if(validation.money($scope.form.money)){
            if(validation.isnull($scope.form.payway.payType)){
             if($scope.form.money>=1){
                   if($scope.form.money<=parseFloat($scope.form.myaccount.balanceAble))
                   {
                      if($scope.form.agree==true){
                        $scope.form.submits=false;
                      var createOrder=[{
                        'productCode':$stateParams.productCode,
                        'amountProduct':$scope.form.money,
                        'unitPrice':$stateParams.singleQuantityAmount,
                        'investQuantity':$scope.form.count,
                        'payType':$scope.form.payway.payType,
                      }];
                      $r("jym_createOrder", createOrder).then(function(data){
                       console.log(data);
                        if(data.respHead.code=="0000"){
                            $scope.form.submits=true;
                            $state.go('orderdetail',{orderId:data.respBean.data[0].orderId});   
                          }else{
                            $scope.form.submits=true;
                            var msg=data.respHead.message;   
                            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                          }
                      },function(err){
                          $scope.form.submits=true;
                          console.log(err);
                      });
                                     
                    }else{msg = "未同意服务协议 !";}  
                 }else{
                   $scope.iopop();
                  // msg = "可用余额不足";
                }
              }else{ msg = "请输入合法金额 !";}
            }else{msg = "请选择支付类型 !";}
           }else{ msg = "请填写正确的购买金额 !";}
        }else{msg = "购买金额不能为空 !";}
      }else{msg = "请填写正确的购买份数 !";}
    }else{
                msg = "购买份数不能为空 !";
    }
      if(msg){
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
      }
      
  };
  
})
.controller('OrderDetailCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $stateParams,$r, validation,$cache,$jf,$h,$timeout) {
  console.log($stateParams.orderId);
  $scope.form={};
  $scope.form.submits=true;
  $scope.form.sendmsgs=true;
  var load=function(){
    var orderDetail=[{
      'orderId':$stateParams.orderId
    }];
    $r("orderDetail", orderDetail ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            //$scope.form.msg=data.respBean;
            $scope.form.orderDetail=data.respBean.data[0];
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
  };
  $scope.$on('$ionicView.enter', function() {
    load();
  });
  $scope.sendmsg=function(){
    if($scope.form.sendmsgs==true){
        $scope.form.sendmsgs=false;
        var timer=40;
        var myTime = setInterval(function() 
          { 
            timer--;
            $scope.form.countdown='等待'+timer+ 's';
            $scope.$digest(); // 通知视图模型的变化
          }, 1000); // 倒计时10-0秒，但算上0的话就是11s ]

         setTimeout(function() { 
          clearInterval(myTime);
           $scope.form.countdown="重新发送"; 
           $scope.form.sendmsgs=true;
           $scope.$digest(); 
        }, 41000);

         $scope.form.bizType='2000';
        var getValidateNo=[{
                      'bizType': $scope.form.bizType,
                     }];
        $r("getValidateNo", getValidateNo ).then(function(data){
           console.log(data);
            if(data.respHead.code=="0000"){
                //$scope.form.msg=data.respBean;
                var msg="验证码发送成功,请注意查收";   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }else{
                var msg=data.respHead.message;   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }
          },function(err){
              console.log(err);
          }); 
        
    }else{
                var msg="验证码已发送";   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
    }
    
   };
  $scope.checkmsg=function(obg){
    console.log(obg);
     var msg;
      if(validation.isnull(obg.msg))
      {
          if(validation.isnull(obg.password))
          {
                $scope.form.submits=false;
                $scope.form.subtext="处理中...";
                $jf.getTokenData().then(function(tokenData){
                  $jf.encodeWithRSA(tokenData.phone, obg.password).then(function(encodedPassword){
                //todo withdraw
                  var order_pay=[{
                    "orderId":obg.orderDetail.orderId,
                    "password":encodedPassword,
                    "checkCode":obg.msg,
                    "bizType":"2000",
                    "amountTotal":obg.orderDetail.amountTotal,
                    "payType":obg.orderDetail.payType,
                    "productCode":obg.orderDetail.productCode,
                    "investQuantity":obg.orderDetail.investQuantity
                  }];
                  $r("jym_payOrder", order_pay).then(function(data){
                          console.log(data);
                          var msg;
                          msg=data.respHead.message;
                          if(data.respHead.code==="0000"){
                                    $timeout(function(){
                                       $scope.form.submits=true;
                                       $scope.form.subtext="完成";
                                    } ,2000); 
//                                    $ionicHistory.goBack();
                                    $state.go('app');
                                    msg="恭喜您,支付成功 !";
                                    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
                          }else{
                            $timeout(function(){
                           $scope.form.submits=true;
                           $scope.form.subtext="完成";
                        } ,2000); 
                            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
                          };
                      console.log(data);
                   },function(err){
                        $timeout(function(){
                           $scope.form.submits=true;
                           $scope.form.subtext="完成";
                        } ,2000); 
                        console.log(err);
                        var msg=err.respHead.message;   
                              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  }); 
                  
                  });
                });
            //$scope.modal.hide();
          }else{
             msg = "登录密码不能为空 !";
             return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
          }
      }else{
        msg = "验证码不能为空 !";
        return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
      }
  };
  
  
})
//orderWX
.controller('OrderWXCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, validation,$stateParams,$r,$cache,$sce,$ionicActionSheet,$timeout,$ionicPopup) {
//  console.log($stateParams.productCode);
	$scope.form={};
  $scope.form.submits=false;
  $scope.form.agree=true;
  $scope.form.count=1;
  $scope.form.contract=[];
  $scope.form.payway={};
  $scope.form.paytypes=[];
  $scope.form.new_user= null;
	//rules
 	$ionicModal.fromTemplateUrl('templates/showwxrules.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.showrules = modal;
  });
  //action sheet
  $scope.showActionsheet = function() {
    
    var hideSheet = $ionicActionSheet.show({
          // titleText: '项目详情',
          buttons: $scope.form.contract,
          cancelText: '取消',
          buttonClicked:function(index){
             $scope.showrulesview();
             //todo change targetUrl
                  console.log($scope.form.contract[index]);
                  //合同详情
                  var wxcontractDetail=[{
                    'type':$scope.form.contract[index].thetype,
                    'money':$scope.form.money,
                    'productCode':$stateParams.productCode,
                  }];
                  $r("wx_contractDetail", wxcontractDetail ).then(function(data){
                   console.log(data);
                   if(data.respHead.code=="0000"){
                        $scope.form.thecontract='合同预览';//$scope.form.contract[index].text
                        $scope.form.content=data.respBean.data[0].content;
                   }else{
                          var msg=data.respHead.message;   
                          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                   }
                 
                  },function(err){
                      console.log(err);
                  });
                  
                  hideSheet();
          }

    });
  };
  //chose payway
  //action sheet
  $scope.chosepayway = function(val) {
    console.log(val);
      var hideSheet = $ionicActionSheet.show({
            titleText: '选择支付方式',
            buttons: $scope.form.paytypes,
            cancelText: '取消',
            buttonClicked:function(index){
                    console.log($scope.form.paytypes[index]);
                    //合同详情
                    $scope.form.payway=$scope.form.paytypes[index];
                    hideSheet();
            }
      });
  };
  
	//rules
	$scope.showrulesview=function(){
	  $scope.showrules.show();
	};
	$scope.closerules = function() {
      $scope.showrules.hide();
	};
  //product
  var load=function(){
      $scope.form.count=1;
      //产品详情
      var productDetail=[{
        'productCode':$stateParams.productCode
      }];
      $r("productDetail", productDetail ).then(function(data){
         console.log(data);
          if(data.respHead.code=="0000"){
              //$scope.form.msg=data.respBean;
              $scope.form.product=data.respBean.data[0];
              $scope.form.money=parseFloat($scope.form.product.singleQuantityAmount)*$scope.form.count;
              $scope.form.input_money='';//$scope.form.money /100
              if($scope.form.product.repayTimeStart==$scope.form.product.repayTimeEnd){
                $scope.form.limit=$scope.form.product.repayTimeStart;
              }else{
                $scope.form.limit=$scope.form.product.repayTimeStart+'~'+$scope.form.product.repayTimeEnd;
              }
//              $scope.form.yield=parseFloat($scope.form.product.yield*100).toFixed(2);
            }else{
              var msg=data.respHead.message;   
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
        },function(err){
            console.log(err);
        });
      
      //获取即付账户信息
      var JfpalAccount=[{"productCode":$stateParams.productCode}];
      $r("productPayAble", JfpalAccount ).then(function(data){
       console.log(data);
       if(data.respHead.code=="0000"){
         $scope.form.submits=true;
         $scope.form.balance=data.respBean.data[0];
         if($scope.form.balance.balance==0){
           $scope.pocketpop();
         }
       }else{
              var msg=data.respHead.message;   
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
       }
//            $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.yiledTakeOutRule);
//            $scope.form.money=$scope.form.balance.unitPrice*$scope.form.count;
      },function(err){
          console.log(err);
      });
      
      //合同列表
      var wxcontractList=[{
                    'productCode':$stateParams.productCode,
      }];
      $r("wx_contractList", wxcontractList ).then(function(data){
       console.log(data);
       if(data.respHead.code=="0000"){
          angular.forEach(data.respBean.data, function(element, idx) {
              var tmp = {
              text : element.name,
              thetype :element.type
            };
            $scope.form.contract.push(tmp);
            console.log($scope.form.contract);
          });
       }else{
              var msg=data.respHead.message;
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
       }
      },function(err){
          console.log(err);
      });
      
      //获取代金券 wx_couponsQuery
//      var wxcouponsQuery=[{}];
//      $r("wx_couponsQuery", wxcouponsQuery ).then(function(data){
//       console.log(data);
//       if(data.respHead.code=="0000"){
//          angular.forEach(data.respBean.data, function(element, idx) {
//            var tmp = {
//              text : parseFloat(element.par)/100+'元代金券',
//              payType :'08',
//              saleCode:element.couponsCode
//            };
//            $scope.form.paytypes.push(tmp);
//            $scope.form.payway = tmp;
//            console.log($scope.form.paytypes);
//          });
//          if (data.respBean.data.length > 0) {
//            console.log(data.respBean.data.length)
//            $scope.form.new_user = true;
//            $scope.form.input_money=$scope.form.money /100;
//
//          }else{
//            $scope.form.new_user = false;
//          }
//       }else{
//              var msg=data.respHead.message;   
//              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
//       }
//      },function(err){
//          console.log(err);
//      });

      //获取支付方式
      var paymentMode=[{productTypeId:$stateParams.productTypeId}];
      $r("paymentMode", paymentMode ).then(function(data){
       console.log(data);
       if(data.respHead.code=="0000"){
         angular.forEach(data.respBean.data, function(element, idx) {
            var tmp = {
              text : element.typeName,
              payType :element.typeCode,
            };
            $scope.form.paytypes.push(tmp);
            console.log($scope.form.paytypes);
          });
          $scope.form.payway=$scope.form.paytypes[0];
       }else{
          var msg=data.respHead.message;   
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
       }
      },function(err){
          console.log(err);
      });
      
  };
  $scope.$on('$ionicView.enter', function() {
      $scope.form.contract=[];
      $scope.form.payway={};
      $scope.form.paytypes=[];
      load();
  });
  //input action
  $scope.putfocus=function(){
    console.log('in putfocus');
    var count=$scope.form.count;
    $scope.form.count='';
    $timeout(function(){
       $scope.form.count=count;
    } ,100); 
  };
  $scope.change=function(){
    if($scope.form.count&&$scope.form.count==0)
    {
      $timeout(function(){
       $scope.form.count=1;
      $scope.form.money=parseFloat($scope.form.product.singleQuantityAmount)*$scope.form.count;
      } ,200); 
    }else if($scope.form.count&&$scope.form.count<0){
      $scope.form.count=1;
      $scope.form.money=parseFloat($scope.form.product.singleQuantityAmount)*$scope.form.count;
    }else{
      $scope.form.money=parseFloat($scope.form.product.singleQuantityAmount)*$scope.form.count;
    }
  };
  $scope.addcount=function() {
    $scope.form.count=parseInt($scope.form.count)+1;
    $scope.change();
  };
  $scope.delcount=function() {
    if($scope.form.count==1){
      $scope.form.count=1;
    }else{
      $scope.form.count=$scope.form.count-1;  
    }
    $scope.change();
  };
  $scope.buyall=function(){
    if($scope.form.balance){
      $scope.form.count=parseInt($scope.form.balance.balanceAble/$scope.form.product.singleQuantityAmount);
      console.log($scope.form.count);
      $scope.change();  
    }else{
      var msg='获取可用余额失败 !';   
      return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
    }
  };
  
  //no account money
  $scope.pocketpop=function(){
       $ionicPopup.show({
              template: '<div class="list_cell text_align_center">钱包余额不足,请充值。</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '充值',
                  type: 'button-positive',
                  onTap: function () {
                   $state.go('recharge');
                  }
                },],
              cssClass:"alertpopup"
       });
    };
  //no account money
  $scope.iopop=function(){
       $ionicPopup.show({
              template: '<div class="list_cell text_align_center">当前可用余额不足,请充值。</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '充值',
                  type: 'button-positive',
                  onTap: function () {
                   $state.go('recharge');
                  }
                },],
              cssClass:"alertpopup"
       });
    };
  //   感叹号提示
  $scope.tk_pop=function(){
		    $ionicPopup.alert({
            title:"",
            template:"根据不同的产品属性,当日充值的金额,最晚可在下一个工作日购买,敬请留意当前可用余额。",
            buttons:[{
              text:"确定",
              onTap:function(){
                console.log('done');
              }			
            }],
			cssClass:"alertpopup"
          });
	};
  $scope.$watch("form.count", function(newV, oldV){
    console.log(newV, oldV);
    var status=(/^[0-9]+\d*$/.test(newV));
    console.log(status);
    if(status){
      $scope.form.count = newV;  
    }
    
  });
  //create order
  $scope.create_order=function(){
     var msg;
//     console.log($scope.form.money<=$scope.form.account.balance);
     console.log($scope.form);
//     $scope.form.product.balance=10000000000;
   if(validation.isnull($scope.form.count)){
    if(validation.number($scope.form.count)){
     if(validation.isnull($scope.form.money)){
        if(validation.money($scope.form.money)){
           if($scope.form.money>=1 && validation.isNumber100Times($scope.form.money)){
             if(validation.isnull($scope.form.payway.payType)){
                 if($scope.form.money<=parseFloat($scope.form.balance.balanceAble))
                 {
                    if($scope.form.agree==true){
                      $scope.form.submits=false;
                    var createOrder=[{
                      'productCode':$stateParams.productCode,
                      'transAmount':$scope.form.money,
                      'payType':$scope.form.payway.payType,
                      'productName':$scope.form.product.productName,
                      'saleCode':$scope.form.payway.saleCode
                    }];
                    $r("wx_createOrder", createOrder).then(function(data){
                     console.log(data);
                      if(data.respHead.code=="0000"){
                          $scope.form.submits=true;
                          $state.go('WXorderdetail',{orderId:data.respBean.data[0].orderId});   
                        }else{
                          $scope.form.submits=true;
                          var msg=data.respHead.message;   
                          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                        }
                    },function(err){
                        $scope.form.submits=true;
                        console.log(err);
                    });
                                   
                  }else{
                      msg = "未同意服务协议 !";
                  }  
                 }else{
                   $scope.iopop();
                   //msg = "可用余额不足";
                 }
                }else{
                  msg = "请选择支付方式 !";
                }
               }else{
                      msg = "请输入合法金额, 且为100.00的整数倍 !";
               }
            }else{
                      msg = "请填写正确的购买金额 !";
            }
          }else{
                   msg = "购买金额不能为空 !";
          }
        }else{
                      msg = "请填写正确的购买份数 !";
                 }
       }else{
          msg = "购买份数不能为空 !";
       }
      if(msg){
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
      }
      
  };
})

.controller('WXOrderDetailCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $stateParams,$r, validation,$cache,$jf,$h,$timeout) {
  console.log($stateParams.orderId);
  $scope.form={};
  $scope.form.submits=true;
  $scope.form.sendmsgs=true;
  var load=function(){
    var orderDetail=[{
      'orderId':$stateParams.orderId
    }];
    $r("wx_orderDetail", orderDetail ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            //$scope.form.msg=data.respBean;
            $scope.form.orderDetail=data.respBean.data[0];
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
  };
  $scope.$on('$ionicView.enter', function() {
    load();
  });
  $scope.sendmsg=function(){
    if($scope.form.sendmsgs==true){
        $scope.form.sendmsgs=false;
        var timer=40;
        var myTime = setInterval(function() 
          { 
            timer--;
            $scope.form.countdown='等待'+timer+ 's';
            $scope.$digest(); // 通知视图模型的变化
          }, 1000); // 倒计时10-0秒，但算上0的话就是11s ]

         setTimeout(function() { 
          clearInterval(myTime);
           $scope.form.countdown="重新发送"; 
           $scope.form.sendmsgs=true;
           $scope.$digest(); 
        }, 41000);

         $scope.form.bizType='3000';
        var getValidateNo=[{
                      'bizType': $scope.form.bizType,
                     }];
        $r("getValidateNo", getValidateNo ).then(function(data){
           console.log(data);
            if(data.respHead.code=="0000"){
                //$scope.form.msg=data.respBean;
                var msg="验证码发送成功,请注意查收 !";   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }else{
                var msg=data.respHead.message;   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }
          },function(err){
              console.log(err);
          }); 
        
    }else{
                var msg="验证码已发送";   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
    }
    
   };
  $scope.checkmsg=function(obg){
    console.log(obg);
     var msg;
      if(validation.isnull(obg.msg))
      {
          if(validation.isnull(obg.password))
          {
                $scope.form.submits=false;
                $scope.form.subtext="处理中...";

                $jf.getTokenData().then(function(tokenData){
                  $jf.encodeWithRSA(tokenData.phone, obg.password).then(function(encodedPassword){
                //todo withdraw
                  var order_pay=[{
                    "orderId":obg.orderDetail.orderId,
                    "password":encodedPassword,
                    "checkCode":obg.msg,
                    "traedType":"4000",
                    "amountTotal":obg.orderDetail.amountTotal,
                    "payType":obg.orderDetail.payType,
                    "productCode":obg.orderDetail.productCode,
                    "orderAmount":obg.orderDetail.amountProduct,
                    "transAmount":obg.orderDetail.amountTotal,
                    "fee":obg.orderDetail.amountFee
                  }];
                  $r("wx_payOrder", order_pay).then(function(data){
                          console.log(data);
                          var msg;
                          msg=data.respHead.message;
                          if(data.respHead.code==="0000"){
                                   $timeout(function(){
                                       $scope.form.submits=true;
                                       $scope.form.subtext="完成";
                                    } ,2000); 
//                                    $ionicHistory.goBack();
                                    $state.go('app');
                                    msg="支付成功,正在投标申请中 !";
                                    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
                          }else{
                            $timeout(function(){
                               $scope.form.submits=true;
                               $scope.form.subtext="完成";
                            } ,2000); 
                            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
                          };
                      console.log(data);
                   },function(err){
                        $timeout(function(){
                           $scope.form.submits=true;
                           $scope.form.subtext="完成";
                        } ,2000); 
                        console.log(err);
                        var msg=err.respHead.message;   
                              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  }); 
                  
                  });
                });
            //$scope.modal.hide();
          }else{
             msg = "登录密码不能为空 !";
             return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
          }
      }else{
        msg = "验证码不能为空 !";
        return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
      }
  };
})
;
