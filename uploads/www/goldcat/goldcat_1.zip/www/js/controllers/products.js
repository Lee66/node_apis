angular.module('controllers')
.controller('productdetailCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $stateParams, $r,$sce) {
    $scope.form={};
    $scope.element={};
    $scope.form.productCode=$stateParams.productCode;
    $scope.form.product_account=0;
    $scope.element.tirtle="产品详情";
      //info
    $ionicModal.fromTemplateUrl('templates/elementinfo.html', {
      scope: $scope
    }).then(function(modal) {
      $scope.elementinfo = modal;
    });
     //info
    $scope.showinfo=function(){
      $scope.elementinfo.show();
    };
    $scope.closeinfo=function(){
      $scope.elementinfo.hide();
    };
    //rules
    $ionicModal.fromTemplateUrl('templates/showrules.html', {
      scope: $scope
    }).then(function(modal) {
      $scope.showrules = modal;
    });
      //action sheet
    $scope.showActionsheet = function(status) {
      if(status=='active'){
        $scope.tirtle="活动详情";
        $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.activityUrl);
      }else if(status=='pro'){
        $scope.tirtle=$scope.form.product.ascriptionName+"理财注册协议";
        $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.registerAgreementUrl);
      }
      $scope.showrulesview();
    };
    //rules
    $scope.showrulesview=function(){
      $scope.showrules.show();
    };
    $scope.closerules = function() {
        $scope.showrules.hide();
    };
    var load=function(){
      var productDetail=[{
        'productCode':$stateParams.productCode,
        'productAscription':$stateParams.action
      }];
      $r("productDetail", productDetail ).then(function(data){
         console.log(data);
          if(data.respHead.code=="0000"){
              //$scope.form.msg=data.respBean;
              $scope.form.product=data.respBean.data[0];
              $scope.form.yield=parseFloat($scope.form.product.yield*100).toFixed(2);
            }else{
              var msg=data.respHead.message;   
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
        },function(err){
            console.log(err);
        });
        
      var amountList=[{}];
      $r("amountList", amountList ).then(function(data){
         console.log(data);
          if(data.respHead.code=="0000"){
               var log;
              angular.forEach(data.respBean.data, function(value, key) {
                console.log(value);
               if(value.productCode==$stateParams.productCode){
                  $scope.form.myproduct=value;
                  $scope.form.product_account=parseFloat($scope.form.myproduct.investAmount)+parseFloat($scope.form.myproduct.yield);
               }
               console.log($scope.form.myproduct);
             }, log);
          
            }else{
              var msg=data.respHead.message;   
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
        },function(err){
            console.log(err);
        });
        
    };
    $scope.$on('$ionicView.enter', function() {
      load();
    });
    $scope.createorder=function(status){
      //console.log($stateParams.productCode);
      console.log(status);
      if(status){
        $state.go('orderwx',{productCode:$stateParams.productCode,productTypeId:$scope.form.product.productTypeId});
      }else{
        $state.go('order',{productCode:$stateParams.productCode,productTypeId:$scope.form.product.productTypeId,singleQuantityAmount:$scope.form.product.singleQuantityAmount});  
      }
                  
    };
    $scope.tackout=function(){
      $state.go('takeout',{productCode:$stateParams.productCode});      
    };
})
.controller('WXproductdetailCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $stateParams, $r,$ionicPopup,$jf,$ionicActionSheet,$sce,$ionicLoading) {
  $scope.form={};
  $scope.element={};
  $scope.form.productCode=$stateParams.productCode;
  $scope.form.submits=false;
  $scope.form.agree=true;
  $scope.form.count=1;
  $scope.form.contract=[];
  $scope.form.btntext="买入";
  $scope.tirtle="理财注册协议";
  $scope.targetUrl = $sce.trustAsResourceUrl('http://api.firstp2p.com/help/user_agreement');
  $scope.element.tirtle="产品详情";
	//rules
 	$ionicModal.fromTemplateUrl('templates/showrules.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.showrules = modal;
  });
  //info
 	$ionicModal.fromTemplateUrl('templates/elementinfo.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.elementinfo = modal;
  });
 //action sheet
  $scope.showActionsheet = function(status) {
    if(status=='active'){
      $scope.tirtle="活动详情";
      $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.activityUrl);
    }else if(status=='pro'){
      $scope.tirtle=$scope.form.product.ascriptionName+"理财注册协议";
      $scope.targetUrl = $sce.trustAsResourceUrl('http://api.firstp2p.com/help/user_agreement');
    }
    $scope.showrulesview();
  };
	//rules
	$scope.showrulesview=function(){
	  $scope.showrules.show();
	};
	$scope.closerules = function() {
      $scope.showrules.hide();
	};
  //info
  $scope.showinfo=function(){
    $scope.elementinfo.show();
  };
  $scope.closeinfo=function(){
    $scope.elementinfo.hide();
  };
  
    var load=function(){
      $ionicLoading.show({
        template: '请稍等...'
      });
      var productDetail=[{
        'productCode':$stateParams.productCode,
        'productAscription':$stateParams.info
      }];
      $r("productDetail", productDetail ).then(function(data){
         console.log(data);
         $ionicLoading.hide();
          if(data.respHead.code=="0000"){
              //$scope.form.msg=data.respBean;
               $scope.form.submits=true;
//              $jf.getTokenData().then(function(tokenData){
//                if(tokenData.authflag=='B'){
//                  $scope.form.submits=false;
//                  var msg='亲,暂不支持购买';
//                  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
//                }else{
//                  $scope.form.submits=true;
//                }
//              });
            }else if(data.respHead.code=="FCXD"){
              $scope.form.submits=false;
              $scope.iopop(); 
            }else if(data.respHead.code=="FCXJ"){
              $scope.form.submits=false;
              $scope.iopop_com(); 
            }else if(data.respHead.code=="FCXF"){
              $scope.form.submits=false;
              $scope.popalert();
            }else{
              $scope.form.submits=false;
              var msg=data.respHead.message;   
              toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
            if(data.respBean){
              $scope.form.product=data.respBean.data[0];
              $scope.form.yield=parseFloat($scope.form.product.yield*100).toFixed(2);  
            }
            
        },function(err){
          $ionicLoading.hide();
            console.log(err);
        });

      
      //账户信息
//      var amountList=[{}];
//      $r("amountList", amountList ).then(function(data){
//         console.log(data);
//          if(data.respHead.code=="0000"){
//               var log;
//              angular.forEach(data.respBean.data, function(value, key) {
//               if(value.productCode==$stateParams.productCode){
//                  $scope.form.myproduct=value;
//                  $scope.form.product_account=parseFloat($scope.form.myproduct.investAmount+$scope.form.myproduct.totalYield);
//               }else{
//                 $scope.form.product_account=0;
//               }
//               console.log($scope.form.myproduct);
//             }, log);
//          
//            }else{
//              var msg=data.respHead.message;   
//              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
//            }
//        },function(err){
//            console.log(err);
//        });
        
    };
    $scope.$on('$ionicView.enter', function() {
      load();
      $scope.form.contract=[];
    });
    $scope.createorder=function(status){
      //console.log($stateParams.productCode);
      console.log(status);
      //todo create wangxin 注册网信
      $scope.createWXAccount();
//      $state.go('orderwx',{productCode:$stateParams.productCode});       
    };
    $scope.createWXAccount=function(){
      if($scope.form.agree==true){
        $scope.form.submits=false;
        $scope.form.btntext="买入中...";
        var wxregister=[{}];
        $r("wx_register", wxregister ).then(function(data){
           console.log(data);
            if(data.respHead.code=="0000"){
                //$scope.form.msg=data.respBean;
                $scope.form.btntext="买入";
                $scope.form.submits=true;
                $state.go('orderwx',{productCode:$stateParams.productCode,productTypeId:$scope.form.product.productTypeId});
              }else{
                $scope.form.btntext="买入";
                $scope.form.submits=true;
                var msg=data.respHead.message;   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }
          },function(err){
              $scope.form.btntext="买入";
              $scope.form.submits=true;
              console.log(err);
          });
        }else{
              var msg = "未同意服务协议";
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
        } 
    };
    $scope.tackout=function(){
      $state.go('takeout',{productCode:$stateParams.productCode});      
    };
    $scope.docheck=function(obg){
      console.log(obg); 
    };
    $scope.popalert=function(){
      $ionicPopup.alert({
            title:"",
            template:"您已经购买过该产品",
            buttons:[{
              text:"确定",
              onTap:function(){
                console.log('done');
              }
            }]
          });
    };
    $scope.iopop=function(){
       $ionicPopup.show({
              template: '<div class="list_cell text_align_center">您还未添加提款账户</div><div class="list_cell text_align_center">无法购买,请先添加提款账户</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '马上添加',
                  type: 'button-positive',
                  onTap: function () {
                    $jf.pushtoAccount();
                  }
                },]
       });
    };
    $scope.iopop_com=function() {
      $ionicPopup.show({
              template: '<div class="list_cell text_align_center">您绑定的银行卡暂不支持购买</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '马上添加',
                  type: 'button-positive',
                  onTap: function () {
                    $jf.pushtoAccount();
                  }
                },]
       });
    };
    $scope.$on('$jf:notificationReceived',function(){
        $jf.hideBottombar('hide');
        load();
    });
})
.controller('comproductinfoCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $stateParams, $r,$ionicPopup,$jf,$ionicActionSheet,$sce,$ionicLoading) {
  $scope.form={};
  $scope.element={};
  $scope.form.productCode=$stateParams.productCode;
  $scope.form.submits=false;
  $scope.form.agree=true;
  $scope.form.count=1;
  $scope.form.contract=[];
  $scope.form.btntext="买入";
  $scope.tirtle="理财注册协议";
  $scope.targetUrl = $sce.trustAsResourceUrl('https://www.baidu.com');
  $scope.element.tirtle="产品详情";
	//rules
 	$ionicModal.fromTemplateUrl('templates/showrules.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.showrules = modal;
  });
  //rules
	$scope.showrulesview=function(){
	  $scope.showrules.show();
	};
	$scope.closerules = function() {
      $scope.showrules.hide();
	};
  //info
 	$ionicModal.fromTemplateUrl('templates/elementinfo.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.elementinfo = modal;
  });
  
  //action sheet
  $scope.showActionsheet = function(status) {
    if(status=='active'){
      $scope.tirtle="活动详情";
      $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.activityUrl);
    }else if(status=='pro'){
      $scope.tirtle=$scope.form.product.ascriptionName+"理财注册协议";
      $scope.targetUrl = $sce.trustAsResourceUrl($scope.form.product.registerAgreementUrl);
    }
    $scope.showrulesview();
  };
  //info
  $scope.showinfo=function(){
    $scope.elementinfo.show();
  };
  $scope.closeinfo=function(){
    $scope.elementinfo.hide();
  };
  
    var load=function(){
      $ionicLoading.show({
        template: '请稍等...'
      });
      var productDetail=[{
        'productCode':$stateParams.productCode,
        'productAscription':$stateParams.info
      }];
      $r("productDetail", productDetail ).then(function(data){
         console.log(data);
         $ionicLoading.hide();
          if(data.respHead.code=="0000"){
              //$scope.form.msg=data.respBean;
               $scope.form.submits=true;
            }else if(data.respHead.code=="FCXD"){
              $scope.form.submits=false;
              $scope.iopop(); 
            }else if(data.respHead.code=="FCXJ"){
              $scope.form.submits=false;
              $scope.iopop_com(); 
            }else if(data.respHead.code=="FCXF"){
              $scope.form.submits=false;
              $scope.popalert();
            }else{
              $scope.form.submits=false;
              var msg=data.respHead.message;   
              toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
            if(data.respBean){
              $scope.form.product=data.respBean.data[0];
              $scope.form.yield=parseFloat($scope.form.product.yield*100).toFixed(2);
                
            }
            
        },function(err){
          $ionicLoading.hide();
            console.log(err);
        });
        
    };
    $scope.$on('$ionicView.enter', function() {
      load();
      $scope.form.contract=[];
    });
    $scope.createorder=function(status){
      //console.log($stateParams.productCode);
      console.log(status);
      $scope.registerAccount();      
    };
    $scope.registerAccount=function(){
      if($scope.form.agree==true){
        $scope.form.submits=false;
        $scope.form.btntext="买入中...";
        var wxregister=[{'productAscription':$stateParams.info}];
        $r("register_common", wxregister ).then(function(data){
           console.log(data);
            if(data.respHead.code=="0000"){
                //$scope.form.msg=data.respBean;
                $scope.form.btntext="买入";
                $scope.form.submits=true;
                $state.go('ordercom',{productCode:$stateParams.productCode,productTypeId:$scope.form.product.productTypeId});
              }else{
                $scope.form.btntext="买入";
                $scope.form.submits=true;
                var msg=data.respHead.message;   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }
          },function(err){
              $scope.form.btntext="买入";
              $scope.form.submits=true;
              console.log(err);
          });
        }else{
              var msg = "未同意服务协议";
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
        } 
    };
    $scope.tackout=function(){
      $state.go('takeout',{productCode:$stateParams.productCode});      
    };
    $scope.docheck=function(obg){
      console.log(obg); 
    };
    $scope.popalert=function(){
      $ionicPopup.alert({
            title:"",
            template:"您已经购买过该产品",
            buttons:[{
              text:"确定",
              onTap:function(){
                console.log('done');
              }
            }]
          });
    };
    $scope.iopop=function(){
       $ionicPopup.show({
              template: '<div class="list_cell text_align_center">您还未添加提款账户</div><div class="list_cell text_align_center">无法购买,请先添加提款账户</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '马上添加',
                  type: 'button-positive',
                  onTap: function () {
                    $jf.pushtoAccount();
                  }
                },]
       });
    };
    $scope.iopop_com=function() {
      $ionicPopup.show({
              template: '<div class="list_cell text_align_center">您绑定的银行卡暂不支持购买</div>',
              title: '',
              scope: $scope,
              buttons: [
                { text: '取消',
                  onTap: function () {
                  }
                },
                { text: '马上添加',
                  type: 'button-positive',
                  onTap: function () {
                    $jf.pushtoAccount();
                  }
                },]
       });
    };
    $scope.$on('$jf:notificationReceived',function(){
        $jf.hideBottombar('hide');
        load();
    });
})
.controller('TakeoutCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, validation ,$r,$stateParams,$jf) {
   $scope.form={};
   $scope.form.submits=true;
   $scope.form.sendmsgs=true;
   $scope.form.countdown="获取验证码";
   var load=function(){
      var financialTakeOut=[{
        "productCode":$stateParams.productCode,
      }];
      $r("jym_financialTakeOut", financialTakeOut ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            $scope.form.myaccount=data.respBean.data[0];
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
    };
    $scope.$on('$ionicView.enter', function() {
      load();
    });
    //sendmsg
	 $ionicModal.fromTemplateUrl('templates/sendmsg.html', {
        scope: $scope
      }).then(function(modal) {
        $scope.modal = modal;
      });
   $scope.closemodal = function() {
        $scope.modal.hide();
   };
   //rules
 	 $ionicModal.fromTemplateUrl('templates/showrules.html', {
     scope: $scope
   }).then(function(modal) {
     $scope.showrules = modal;
   });
	 //rules
	 $scope.showrulesview=function(){
	   $scope.showrules.show();
	 };
	 $scope.closerules = function() {
      $scope.showrules.hide();
	 };
   $scope.change=function () {
		var date=((parseFloat($scope.form.money)*100).toFixed(2)).split(".");
		console.log(date);
		if(date[1]>0){
            $scope.form.money=parseFloat(date[0])/100;    
        };
	}; 
   $scope.takeoutmoney=function(){
     var msg;
     // console.log(validation.money($scope.form.money));
//     console.log($scope.form.money<=$scope.form.account.balance);
     // console.log($scope.form);
     var moneys=(parseFloat($scope.form.money)*100);
     var finanmonsy=parseFloat($scope.form.myaccount.financialBalance);
     // console.log(parseFloat($scope.form.money));
     if(validation.isnull($scope.form.money)){
        if(validation.money($scope.form.money)){
           if(moneys>=1){
             if(moneys>finanmonsy){
              // console.log(moneys);
              // console.log(finanmonsy);
               msg = "可取出金额不足,请重新输入取出金额 !";
             }else{
              $scope.checkmsg($scope.form); 
             } 
           }else{
                  msg = "请输入合法金额 !";
           }
        }else{
                  msg = "请填写正确的取出金额 !";
        }
      }else{
               msg = "请输入取出金额 !";
      }
      if(msg){
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
      }
   };
   
  $scope.sendmsg=function(){
    if($scope.form.sendmsgs==true){
        $scope.form.sendmsgs=false;
        var timer=40;
        var myTime = setInterval(function() 
          { 
            timer--;
            $scope.form.countdown='等待'+timer+ 's';
            $scope.$digest(); // 通知视图模型的变化
          }, 1000); // 倒计时10-0秒，但算上0的话就是11s ]

         setTimeout(function() { 
          clearInterval(myTime);
           $scope.form.countdown="重新发送"; 
           $scope.form.sendmsgs=true;
           $scope.$digest(); 
        }, 41000);

         $scope.form.bizType='2001';
        var getValidateNo=[{
                      'bizType': $scope.form.bizType,
                     }];
        $r("getValidateNo", getValidateNo ).then(function(data){
           console.log(data);
            if(data.respHead.code=="0000"){
                //$scope.form.msg=data.respBean;
                var msg="验证码发送成功,请注意查收";   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
              }else{
                var msg=data.respHead.message;   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
              }
          },function(err){
              console.log(err);
          }); 
        
    }else{
                var msg="验证码已发送";   
                return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
    }
    
   };
  $scope.checkmsg=function(obg){
    console.log(obg);
     var msg;
      if(validation.isnull(obg.message))
      {
//          if(validation.isnull(obg.password))
//          {
                $scope.form.submits=false;
                $scope.form.subtext="取出中...";
//                $jf.getTokenData().then(function(tokenData){
//                  $jf.encodeWithRSA(tokenData.phone, obg.password).then(function(encodedPassword){
                //todo withdraw
                 var ransomProduct=[{
                   "bizType":"2001",
                   "checkCode":obg.message,
                   "productCode":$stateParams.productCode,
                   "Password":"encodedPassword",
                   "amount":parseInt(parseFloat(obg.money)*100),
                 }];
                  $r("jym_ransomProduct", ransomProduct ).then(function(data){
                     console.log(data);
                     if(data.respHead.code=="0000")
                     {
                      msg='取出申请提交成功 !';   
                      $scope.$emit("$ionicView.enter");
                      $ionicHistory.goBack();
                     }else{
                       msg=data.respHead.message;   
                    }
                    $scope.form.submits=true;
                    $scope.form.subtext="取出";
                    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  },function(err){
                       $scope.form.submits=true;
                       $scope.form.subtext="取出";
                      console.log(err);
                      var msg=err.respHead.message;   
                            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  });
                   
//                  });
//                });
            //$scope.modal.hide();
//          }else{
//             msg = "登录密码不能为空";
//             return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
//          }
      }else{
        msg = "请输入验证码 !";
        return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml');
      }
  };
  $scope.takeoutAll=function(){
    $scope.form.money=parseFloat($scope.form.myaccount.financialBalance)/100;
  };
})
.controller('activityCtrl', function($scope, $ionicActionSheet,$r,$jf,toaster,$ionicHistory) {
  $scope.form={};
  $scope.form.hotline;
  $scope.form.appname;
  $scope.form.company;
  $jf.getTokenData().then(function(tokenData){
    $scope.form.hotline =  tokenData.hotline;
    $scope.form.appname =  tokenData.appname;
    $scope.form.company = tokenData.company;
  });
  var load=function(){
  var couponsLis=[{
    }];
  $r("wx_couponsList", couponsLis ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
          $scope.data = data.respBean.data;
        }else{
          var msg=data.respHead.message;   
          return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
        }
      },function(err){
          console.log(err);
    });
  };

  $scope.$on('$ionicView.enter', function() {
      load();
    });
  $scope.invite = function() {

    $ionicActionSheet.show({
      titleText: '分享到',
      buttons: [
        { text: '<div class="margin_auto"><img class="bank_icons" src="img/public/invite_wx.png"/></div><div class="line_height_14 font_small textclolor_333">微信</div>' },
        { text: '<div class="margin_auto"><img class="bank_icons" src="img/public/invite_py.png"/></div><div class="line_height_14 font_small textclolor_333">朋友圈</div>' },
        { text: '<div class="margin_auto"><img class="bank_icons" src="img/public/invite_dx.png"/></div><div class="line_height_14 font_small textclolor_333">短信</div>' },
      ],
      cancelText: '取消分享',
      cssClass: 'activityInvite',
      cancel: function() {
        return false;
        console.log('取消');
      },
      buttonClicked:function(index){
        var data;
        console.log(index);
        // $window.WeChat.Scene.session => 1,微信
        // $window.WeChat.Scene.timeline => 2,朋友圈
      $jf.getTokenData().then(function(tokenData){
        var inviteMobile = tokenData.phone;
        var shareUrl = 'https://mfront.jfpal.com:8443/financial_prepo/toShare?';
        var appUser = tokenData.appUser;
        var descript = '大型年中活动，火热进行中！新手100元理财代金券免费领！百万老用户诚邀您加入！';
        var sharetitle = '百万理财代金券，免费领取!';
        if(index == 0){
          data={title:sharetitle,description:descript,url:shareUrl+'inviteMobile='+inviteMobile+'&appUser='+appUser}
          console.log(data)
          $jf.shareToWeChart(data,1);
        }else if(index == 1){
          data={title:sharetitle,description:descript,url:shareUrl+'inviteMobile='+inviteMobile+'&appUser='+appUser}
          console.log(data)
          $jf.shareToWeChart(data,2);
        }else{
          data = descript+shareUrl+'inviteMobile='+inviteMobile+'&appUser='+appUser
          console.log(data)
           $jf.shareToSMS(data);
        }
      });
        return true;
      }
    });

  };
  $scope.$back = function(){
    $ionicHistory.goBack();
  }
})
;