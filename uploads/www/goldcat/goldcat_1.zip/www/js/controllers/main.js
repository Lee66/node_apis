angular.module('controllers', [])
.controller('MainListCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r, $window,$jf,$ionicSlideBoxDelegate,$ionicScrollDelegate,_,$sce,$timeout) {
    $scope.form={};
    $scope.form.tabstatu='productlist';
    $scope.noMoreItemsAvailable = true;
    $scope.form.pageIndex=1;
    $scope.tirtle="活动详情";
    $scope.targetUrl = $sce.trustAsResourceUrl('https://www.baidu.com/');
    //rules
    $ionicModal.fromTemplateUrl('templates/showrules.html', {
      scope: $scope
    }).then(function(modal) {
      $scope.showrules = modal;
    });
    //rules
    $scope.showrulesview=function(banner){
      $scope.showrules.show();
      console.log(banner.imgUrl);
      $scope.targetUrl = $sce.trustAsResourceUrl(banner.indexUrl);
    };
    $scope.closerules = function() {
        $scope.showrules.hide();
    };
   
    var load=function(){
//      $scope.form={};
    $scope.circle={};
      //常规配置
//    $scope.circle.options = [{
//        trackColor:'#999',//线条背景色
//        barColor:'#fd5023',//线条颜色
//        scaleColor:false,
//        lineWidth:50,//线条大小
//        lineCap:'circle',//线条形状
//        size:30//circle size
//    }];
    var bannerList=[{}];
    $r("bannerList", bannerList ).then(function(data){
        console.log(data);
        if(data.respHead.code=="0000"){
            $scope.form.banners=data.respBean.data;
            $scope.$broadcast('scroll.refreshComplete');
            $timeout(function(){
              $ionicSlideBoxDelegate.update();
            } ,10);
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
      var productList=[{'pageIndex':1,'pageNum':5}];
      $r("productList", productList ).then(function(data){
         console.log(data);
          if(data.respHead.code=="0000"){
              //$scope.form.msg=data.respBean;
              $scope.form.products=data.respBean.data;
              $scope.form.pageIndex=2;
              $scope.noMoreItemsAvailable = false;
              $scope.$broadcast('scroll.refreshComplete');
            }else{
              var msg=data.respHead.message;   
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
        },function(err){
            console.log(err);
        });
      
      var myAccount=[{}];
      $r("myAccount", myAccount ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            $scope.form.myaccount=data.respBean.data[0];
            $scope.form.accountnum=parseFloat($scope.form.myaccount.productBalance)+parseFloat($scope.form.myaccount.blockedBalance);
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
     
     $jf.getTokenData().then(function(tokenData){
      $scope.form.hotline =  tokenData.hotline;
      $scope.form.appname =  tokenData.appname;
      $scope.form.company = tokenData.company;
      });
      
    };//load over
    $scope.$on('$ionicView.enter', function() {
      load();
      $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop(true);
      $scope.showbottombar();
    });
    $scope.$on('$jf:notificationReceived',function(){
        load();
    });
    $scope.doRefresh=function(){
        load();
    };
    $scope.backToApp = function() {
      $window.context.quit();
    };
    //cancle bottoms bar
    $scope.hidebottombar=function(){
      console.log('hide bottom bar');
      $jf.hideBottombar('hide');
    };
    $scope.showbottombar=function(){
      console.log('show bottom bar');
     $jf.hideBottombar('show');
    };
    
    $scope.goproduct=function(obg){
        console.log(obg);
        if(obg.productAscription=="JYM"){
          $state.go('productdetail',{productCode:obg.productCode,action:obg.productAscription});
        }else if(obg.productAscription=="WANGXIN"){
          $state.go('productinfo',{productCode:obg.productCode,info:obg.productAscription});  
        }else{
          $state.go('comproductinfo',{productCode:obg.productCode,info:obg.productAscription});  
        }
        
    };
    
    //slide box
    $scope.slideIndex = 0;
            // Called each time the slide changes
    $scope.slideChanged = function(index) {
        $scope.slideIndex = index;
        console.log("slide Change");

        if ($scope.slideIndex == 0){
            console.log("slide 1");
        }

        else if ($scope.slideIndex == 1){
            console.log("slide 2");
            $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop();
        }

    };
   
    $scope.activeSlide = function (index) {
        $ionicSlideBoxDelegate.slide(index);
    };
    
    
    $scope.loadMoreData = function() {
             var reqBody= [{
                  "pageNum":5,
                  "pageIndex":$scope.form.pageIndex,
                }];
             $r("productList", reqBody).then(function(data){
                console.log(data);
                 if(data.respHead.code=="0000"){
                      if(($scope.form.products && $scope.form.products.length >= data.respBean.page.totalRecord)||data.respBean.page.totalRecord==0){
                          $scope.noMoreItemsAvailable = true;

                      }else{
                        _.each(data.respBean.data, function(item){
                        $scope.form.products.push(item);
                        });
                        $scope.form.pageIndex=data.respBean.page.pageIndex+1;
       
                      }
                  }else{
                    $scope.noMoreItemsAvailable = true;
                    var msg=data.respHead.message;   
                    return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
                  }
              },function(err){
                $scope.noMoreItemsAvailable = true;
                console.log(err);
            });
            $scope.$broadcast('scroll.infiniteScrollComplete');
            
          };
     $scope.lockSlide = function () {
        $ionicSlideBoxDelegate.enableSlide( false );
    }
})
.controller('AccountAndMyproductCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r) {
    var load=function(){
      var myAccount=[{}];
      $r("myAccount", myAccount ).then(function(data){
       console.log(data);
        if(data.respHead.code=="0000"){
            $scope.form.myaccount=data.respBean.data[0];
            $scope.form.accountnum=parseFloat($scope.form.myaccount.productBalance+$scope.form.myaccount.balance+$scope.form.myaccount.blockedBalance);
          }else{
            var msg=data.respHead.message;   
            return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
          }
      },function(err){
          console.log(err);
      });
      var amountList=[{}];
      $r("amountList", amountList ).then(function(data){
         console.log(data);
          if(data.respHead.code=="0000"){
              $scope.form.myproduct=data.respBean.data;
              if($scope.form.myproduct[0]){
                $scope.form.product_account=parseFloat($scope.form.myproduct[0].investAmount+$scope.form.myproduct[0].totalYield);  
              }else{
                $scope.form.product_account=0;
              }
            }else{
              var msg=data.respHead.message;   
              return  toaster.pop('warning', null, '<ul><li>'+  msg + '</li></ul>', null, 'trustedHtml'); 
            }
        },function(err){
            console.log(err);
        });
    };
    $scope.$on('$ionicView.enter', function() {
      load();
    });
})
.controller('ShowPopCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r, $ionicPopup) {
  //rules
   $scope.form.clickstatus='tab1';
 	 $ionicModal.fromTemplateUrl('templates/showyeld.html', {
     scope: $scope
   }).then(function(modal) {
     $scope.showrules = modal;
   });
   $scope.showagreement=function(){
	   $scope.showrules.show();
	 };
	 $scope.closeagreement = function() {
      $scope.showrules.hide();
	 };
   $scope.tabshow=function(status){
          $scope.form.clickstatus=status;
   };
  $scope.showpop=function(){
    var confirmPopup = $ionicPopup.confirm({
       title: '收益及取出规则',
       template: '<div class="list_cell text_align_left">收益详见产品信息页。随时赎回，最</div><div class="list_cell text_align_left">快当日到达余额账户。每人单次最高赎回5万,每人一日最多赎回2次。</div>',
       buttons: [
          {
            text: '<b>确认</b>',
            onTap: function() { 
            }
          }
        ]
     });
  };
    
})
.controller('rulelistCtrl', function($scope, $ionicModal,toaster, $state, $ionicHistory, $r, $ionicPopup,$jf) {

  $scope.form={};
  $jf.getTokenData().then(function(tokenData){
      $scope.form.hotline =  tokenData.hotline;
      $scope.form.appname =  tokenData.appname;
      $scope.form.company = tokenData.company;
   });
  //rules
 	$ionicModal.fromTemplateUrl('templates/rulecontent.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.showrules = modal;
  });
	//rules
	$scope.showrulesview=function(){
	  $scope.showrules.show();
	};
	$scope.closerules = function() {
      $scope.showrules.hide();
	};
  $scope.showrulesfun=function(status){
    console.log(status);
    $scope.form.content=status;
    $scope.showrules.show();
  };
  $scope.back = function(){
    $ionicHistory.goBack();
  }
})
;